Python 3.11.3 (tags/v3.11.3:f3909b8, Apr  4 2023, 23:49:59) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

=================== RESTART: H:\PYTHON_237\Assignment No.4.py ==================
data of test data of player:-
 
All player name:-
 0       SR Tendulkar (INDIA)
1           RT Ponting (AUS)
2         JH Kallis (ICC/SA)
3       R Dravid (ICC/INDIA)
4              AN Cook (ENG)
                ...         
2996         CA Snedden (NZ)
2997        VN Swamy (INDIA)
2998    Usman Shinwari (PAK)
2999      CM Willoughby (SA)
3000         JW Wilson (AUS)
Name: Player, Length: 3001, dtype: object
Find Player who had did maximum centuries in test matches:- AJ Strauss (ENG) 
 Number Of  Century:- 51 


Find Player who had did maximum Half-centuries in test matches:- Azhar Ali (PAK) 
 Number of Half-Centuru:- 68 


Find median of all players Batting Average:- 17.33 


Find median of all players Batting Average:- 19.93661112962346 


show player name who had debut before 1900:-
 169           C Hill (AUS)
183       VT Trumper (AUS)
266         W Rhodes (ENG)
272       SE Gregory (AUS)
313       TW Hayward (ENG)
               ...        
2948        GA Kempis (SA)
2953    JEP McMaster (ENG)
2958         AW Mold (ENG)
2975        EJ Tyler (ENG)
2979        CS Wimble (SA)
Name: Player, Length: 249, dtype: object 

Count:- 249 


show player name who had played upto 1900:-
 455     A Shrewsbury snr (ENG)
466             G Giffen (AUS)
505         AC Bannerman (AUS)
511             WG Grace (ENG)
550          AE Stoddart (ENG)
                 ...          
2948            GA Kempis (SA)
2953        JEP McMaster (ENG)
2958             AW Mold (ENG)
2975            EJ Tyler (ENG)
2979            CS Wimble (SA)
Name: Player, Length: 211, dtype: object 

Count:- 211 


show player name who had played from india:-
 0          SR Tendulkar (INDIA)
3          R Dravid (ICC/INDIA)
11          SM Gavaskar (INDIA)
18           VVS Laxman (INDIA)
22         V Sehwag (ICC/INDIA)
                 ...           
2976    M Venkataramana (INDIA)
2985            HT Dani (INDIA)
2991     V Rajindernath (INDIA)
2995          RC Shukla (INDIA)
2997           VN Swamy (INDIA)
Name: Player, Length: 292, dtype: object 

Count:- 292 


show player name who had played from England:-
 4            AN Cook (ENG)
15          GA Gooch (ENG)
24        AJ Stewart (ENG)
25          DI Gower (ENG)
26      KP Pietersen (ENG)
               ...        
2983         JC Clay (ENG)
2988          A Khan (ENG)
2989    JCW MacBryan (ENG)
2992         HD Read (ENG)
2993         CF Root (ENG)
Name: Player, Length: 692, dtype: object 

Count:- 692 


show player name who had played from Australia:-
 1       RT Ponting (AUS)
9        AR Border (AUS)
10        SR Waugh (AUS)
20       MJ Clarke (AUS)
21       ML Hayden (AUS)
              ...       
2972    HM Thurlow (AUS)
2978      P Wilson (AUS)
2982      PJ Allan (AUS)
2984     DJ Cullen (AUS)
3000     JW Wilson (AUS)
Name: Player, Length: 453, dtype: object 

Count:- 453 


show player name who had played from South Africa:-
 2            JH Kallis (ICC/SA)
13                 HM Amla (SA)
14            GC Smith (ICC/SA)
19          AB de Villiers (SA)
41               G Kirsten (SA)
                 ...           
2971             SD Snooke (SA)
2973            LR Tuckett (SA)
2974    PS Twentyman-Jones (SA)
2979             CS Wimble (SA)
2999         CM Willoughby (SA)
Name: Player, Length: 340, dtype: object 

Count:- 340 


show player name who had played from Pakistan:-
 12             Younis Khan (PAK)
16           Javed Miandad (PAK)
17      Inzamam-ul-Haq (ICC/PAK)
35         Mohammad Yousuf (PAK)
68               Azhar Ali (PAK)
                  ...           
2959         Nadeem Ghauri (PAK)
2981     Ali Hussain Rizvi (PAK)
2986         Farrukh Zaman (PAK)
2994        Shahid Mahboob (PAK)
2998        Usman Shinwari (PAK)
Name: Player, Length: 238, dtype: object 

Count:- 238 


show player name who had played from New zealand:-
 46          SP Fleming (NZ)
48         LRPL Taylor (NZ)
58         BB McCullum (NZ)
59       KS Williamson (NZ)
83            MD Crowe (NZ)
               ...         
2922         DG Sewell (NZ)
2933    LA Butterfield (NZ)
2950         IB Leggat (NZ)
2966           CG Rowe (NZ)
2996        CA Snedden (NZ)
Name: Player, Length: 275, dtype: object 

Count:- 275 


show player name who had played from West-indies:-
 6          BC Lara (ICC/WI)
7        S Chanderpaul (WI)
23        IVA Richards (WI)
28           GS Sobers (WI)
34        CG Greenidge (WI)
               ...         
2947    AS Jaggernauth (WI)
2963         KK Peters (WI)
2965        LA Roberts (WI)
2987         AB Howard (WI)
2990         LR Pierre (WI)
Name: Player, Length: 318, dtype: object 

Count:- 318 


find player name who had not out most of time in test:- N Kapil Dev (INDIA)
How Many Time the player had not out most of time:- 89 


find player name who had did higest score in test:- Yasir Hameed (PAK)
Highest Score:- 400 


Show Player who had did zero centuries in test matches:-
 185           SK Warne (AUS)
296      CPS Chauhan (INDIA)
315           DL Murray (WI)
334         N Dickwella (SL)
343         MD Marshall (WI)
                ...         
2996         CA Snedden (NZ)
2997        VN Swamy (INDIA)
2998    Usman Shinwari (PAK)
2999      CM Willoughby (SA)
3000         JW Wilson (AUS)
Name: Player, Length: 2223, dtype: object
Centuries:- 0 


Show Player who had did zero centuries in test matches:-
 536            NM Lyon (AUS)
541       Waqar Younis (PAK)
561         FS Trueman (ENG)
576            M Morkel (SA)
578       CJ McDermott (AUS)
                ...         
2996         CA Snedden (NZ)
2997        VN Swamy (INDIA)
2998    Usman Shinwari (PAK)
2999      CM Willoughby (SA)
3000         JW Wilson (AUS)
Name: Player, Length: 1639, dtype: object
Half-Centuries:- 0 


Show Player name who had Debut 1901 to 1950 in between them:-
 42        WR Hammond (ENG)
52        DG Bradman (AUS)
54          L Hutton (ENG)
65         RN Harvey (AUS)
71       DCS Compton (ENG)
               ...        
2989    JCW MacBryan (ENG)
2990        LR Pierre (WI)
2992         HD Read (ENG)
2993         CF Root (ENG)
2996       CA Snedden (NZ)
Name: Player, Length: 632, dtype: object
Count:- 632 


Show Player name who had Debut after the 1950:-
 0       SR Tendulkar (INDIA)
1           RT Ponting (AUS)
2         JH Kallis (ICC/SA)
3       R Dravid (ICC/INDIA)
4              AN Cook (ENG)
                ...         
2995       RC Shukla (INDIA)
2997        VN Swamy (INDIA)
2998    Usman Shinwari (PAK)
2999      CM Willoughby (SA)
3000         JW Wilson (AUS)
Name: Player, Length: 2120, dtype: object
Count:- 2120 


show player name who had played upto 1900:-
 455     A Shrewsbury snr (ENG)
466             G Giffen (AUS)
505         AC Bannerman (AUS)
511             WG Grace (ENG)
550          AE Stoddart (ENG)
                 ...          
2948            GA Kempis (SA)
2953        JEP McMaster (ENG)
2958             AW Mold (ENG)
2975            EJ Tyler (ENG)
2979            CS Wimble (SA)
Name: Player, Length: 211, dtype: object
Count:- 211 


Find mean of all players Centuries:- 1.3985338220593135
Find mean of all players Half Centuries:- 3.391536154615128 


Describe the Country Column:-
 count        3001
unique         15
top       England
freq          692
Name: Country, dtype: object
Describe the data set:-
        Debut Year  Upto year played  ...    Centuries      Fifties
count  3001.00000       3001.000000  ...  3001.000000  3001.000000
mean   1968.51083       1973.019660  ...     1.398534     3.391536
std      38.54157         38.535515  ...     4.248818     7.642533
min    1877.00000       1877.000000  ...     0.000000     0.000000
25%    1946.00000       1949.000000  ...     0.000000     0.000000
50%    1977.00000       1982.000000  ...     0.000000     0.000000
75%    2001.00000       2005.000000  ...     1.000000     3.000000
max    2019.00000       2019.000000  ...    51.000000    68.000000

[8 rows x 9 columns] 


